# WartegFoodExtended
WartegFoodExtended is a mod for Project Zomboid which adds several Indonesian food recipes.

## Roadmap
- Updates : Indonesian Instant Food & Beverages roadmap Batch I (Done)
- Updates : Indonesian Instant Food & Beverages roadmap Batch II (Planned)
- Updates : Indonesian Household Foods Recipes (Soon)
- Updates : Indonesian Traditional Foods Recipes (Nearly Future)

## Important Link
- Subscribe to Steam Workshop [Click Here](https://steamcommunity.com/sharedfiles/filedetails/?id=2873240250)
- Mod detail changelog [Click Here](https://steamcommunity.com/sharedfiles/filedetails/changelog/2873240250)
- Let us know if you found a bug [Click Here](https://steamcommunity.com/sharedfiles/filedetails/discussions/2873240250)
- Detailed item list [Click Here](https://github.com/projectzomboid-id/WartegFoodExtended/wiki/Warteg-Food-Extended-Item-List)
